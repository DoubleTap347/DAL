﻿using CustomerDAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using MySql.Data.MySqlClient;
using System.Data;
using System.Data.Common;
using CustomerDAL.Services;


namespace CustomerDAL.Services
{
    public class ProjectsService : IProjectService
    {
        List<Project> projects = new List<Project>();
        string connectionString = ConfigurationManager.ConnectionStrings["CustardConnection"].ConnectionString.ToString();

        public List<Project> RetrieveProjects()
        {
            List<Project> projects = new List<Project>();

            MySqlDataReader dataReader;

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                //Sql query to be executed in the database
                MySqlCommand command =
                    new MySqlCommand("SELECT Id, First_Name, Last_Name " +
                    "FROM customers ORDER BY Id;", conn);
                conn.Open();

                dataReader = command.ExecuteReader();

                if (dataReader.HasRows)
                {
                    while (dataReader.Read())
                    {
                        projects.Add(new Project
                            (
                                dataReader.GetInt32("Id"),
                                dataReader.GetString("Title"),
                                dataReader.GetInt32("FreelancerId")
                                ));
                    }
                }
                conn.Close();
            }

            return projects;
        }
    }
}