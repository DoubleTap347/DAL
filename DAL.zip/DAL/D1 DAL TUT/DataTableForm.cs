﻿using CustomerDAL.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace D1_DAL_TUT
{
    public partial class DataTableForm : Form
    {
        private readonly ICustomerService customersService;
        private DataSet dataSetCustomers;
        public DataTableForm()
        {
            customersService = new CustomerService();
            this.gridViewCustomers = new DataGridView();

            InitializeComponent();
        }

        private void InitializeDataGrid()
        {
            try
            {
                dataSetCustomers = customersService.GetDisconnectedData();

                this.gridViewCustomers.DataSource = dataSetCustomers.Tables["Customers"];
                //this.gridViewCustomers.DataMember = "Customers"; //Caused error label to appear
            }
            catch(Exception ex)
            {
                lblStatus.Text = "An error has occurred!";
                lblError.Text = ex.Message;
            }
        }

        private void btnDashboard_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            InitializeDataGrid();
        }

        private void gridViewCustomers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}