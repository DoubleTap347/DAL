﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CustomerDAL.Services;
using CustomerDAL.Models;
using System.Configuration;

namespace D1_DAL_TUT
{
    public partial class Dashboard : Form
    {
        private readonly IProjectService projectsService;
        private readonly ICustomerService customerService;

        public Dashboard()
        {

            customerService = new CustomerService();
            projectsService = new ProjectsService();
            InitializeComponent();
        }

        private void btnCustomers_Click(object sender, EventArgs e)
        {
            listBoxResults.Items.Clear();

            try
            {
                List<Customer> customers = new List<Customer>();
                customers = customerService.RetrieveCustomers();

            }
            catch (Exception ex)
            {
                lblStatus.Text = "An error has occurred!";
                lblError.Text = ex.Message;
                listBoxResults.Items.Add(ex.StackTrace);
            }
        }
        
        private void btnGetSingleFreelancer_Click(object sender, EventArgs e)
        {

        }
        //Click events below. Show the forms to allow the user to CRUD
        private void button2_Click(object sender, EventArgs e) //Add freelancer button click event
        {
            new AddCustomerForm().Show();
        }

        private void btnSearchProjects_Click(object sender, EventArgs e)
        {

        }

        private void btnUpdateFreelancer_Click(object sender, EventArgs e)
        {
            new UpdateCustomerForm().Show();
        }

        private void btnDeleteFreelancer_Click(object sender, EventArgs e)
        {
            new DeleteCustomerForm().Show();
        }

        private void btnTables_Click(object sender, EventArgs e)
        {
            new DataTableForm().Show();
        }

        private void btnProjects_Click(object sender, EventArgs e)
        {
            listBoxResults.Items.Clear();

            try
            {
                List<Customer> customers = new List<Customer>();
                customers = customerService.RetrieveCustomers();

                if (customers != null && customers.Count > 0)
                {
                    foreach (Customer c in customers)
                    {
                        listBoxResults.Items
                            .Add($"Customer: {c.First_Name}, " +
                            $"Id: {c.Id}, " +
                            $"Linked to customer: {c.Last_Name}.");
                    }
                }
                else
                {
                    listBoxResults.Items.Add("No results were found.");
                }
            }
            catch (Exception ex)
            {
                lblStatus.Text = "An error occurred retrieving customer data";
                lblError.Text = ex.Message;

                listBoxResults.Items.Add(ex.StackTrace);
            }
        }

        private void btnGetSingleFreelancer_Click_1(object sender, EventArgs e)
        {

        }

        private void btnGetSingleCustomer_Click(object sender, EventArgs e)
        {
            //Clear listbox first
            listBoxResults.Items.Clear();

            //Try catch to avoid crashes
            try
            {
                //Retrieve customer
                Customer customer = customerService.RetrieveCustomersByLastName(txtCustomerName.Text);

                // If freelancer is not null
                // the lastname is not empty and is not whitespace
                if (customer != null &&
                    !String.IsNullOrEmpty(customer.Last_Name) &&
                    !String.IsNullOrWhiteSpace(customer.Last_Name))
                {
                    //Add the information to the listbox
                    listBoxResults.Items.Add(
                        $"customer: {customer.First_Name} {customer.Last_Name}, " +
                        $"Id: {customer.Id}");
                }
                else
                {
                    listBoxResults.Items.Add(
                        "Could not find last name: " +
                        txtCustomerName.Text);
                }
            }
            catch (Exception ex)
            {
                lblStatus.Text = "An error has occured!";
                lblError.Text = ex.Message;

                listBoxResults.Items.Add(ex.StackTrace);
            }
        }
    }
}