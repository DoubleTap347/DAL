﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CustomerDAL.Services;
using CustomerDAL.Models;

namespace D1_DAL_TUT
{
    public partial class Dashboard : Form
    {
        private readonly IProjectService projectsService;
        private readonly ICustomerService customerService;

        public Dashboard()
        {

            customerService = new CustomerService();
            projectsService = new ProjectsService();
            InitializeComponent();
        }

        private void btnCustomers_Click(object sender, EventArgs e)
        {
            listBoxResults.Items.Clear();

            try
            {
                List<Customer> freelancers = new List<Customer>();
                freelancers = CustomerService.RetrieveCustomers();

            }
            catch (Exception ex)
            {
                lblStatus.Text = "An error has occurred!";
                lblError.Text = ex.Message;
                listBoxResults.Items.Add(ex.StackTrace);
            }
        }
        private void btnGetSingleFreelancer_Click(object sender, EventArgs e)
        {
            //Clear listbox first
            listBoxResults.Items.Clear();

            //Try catch to avoid crashes
            try
            {
                //Retrieve customer
                Customer customer = CustomerService.RetrieveCustomersByLastName(txtFreelancerName.Text);

                // If freelancer is not null
                // the lastname is not empty and is not whitespace
                if (customer != null &&
                    !String.IsNullOrEmpty(customer.LastName) &&
                    !String.IsNullOrWhiteSpace(customer.LastName))
                {
                    //Add the information to the listbox
                    listBoxResults.Items.Add(
                        $"Customer: {customer.FirstName} {customer.LastName}, " +
                        $"Id: {customer.Id}");
                }
                else
                {
                    listBoxResults.Items.Add(
                        "Could not find last name: " +
                        txtFreelancerName.Text);
                }
            }
            catch (Exception ex)
            {
                lblStatus.Text = "An error has occured!";
                lblError.Text = ex.Message;

                listBoxResults.Items.Add(ex.StackTrace);
            }
        }
        //Click events below. Show the forms to allow the user to CRUD
        private void button2_Click(object sender, EventArgs e) //Add freelancer button click event
        {
            new AddCustomerForm().Show();
        }

        private void btnSearchProjects_Click(object sender, EventArgs e)
        {

        }

        private void btnUpdateFreelancer_Click(object sender, EventArgs e)
        {
            new UpdateCustomerForm().Show();
        }

        private void btnDeleteFreelancer_Click(object sender, EventArgs e)
        {
            new DeleteCustomerForm().Show();
        }

        private void btnTables_Click(object sender, EventArgs e)
        {
            new DataTableForm().Show();
        }

        private void btnProjects_Click(object sender, EventArgs e)
        {

        }

        private void btnGetSingleFreelancer_Click_1(object sender, EventArgs e)
        {

        }
    }
}