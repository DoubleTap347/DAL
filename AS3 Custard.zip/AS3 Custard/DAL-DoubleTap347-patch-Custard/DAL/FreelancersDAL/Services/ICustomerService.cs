﻿using CustomerDAL.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace CustomerDAL.Services
{
    public interface ICustomerService
    {
        List<Customer> RetrieveCustomers();
        Customer AddCustomer(Customer customer);
        Customer UpdateCustomer(Customer customer);
        bool DeleteCustomer(int customerId);
        DataSet GetDisconnectedData();
        Customer RetrieveCustomersByLastName(string text);
    }
}