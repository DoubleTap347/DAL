﻿using CustomerDAL.Models;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Common;
using CustomerDAL.Services;

namespace CustomerDAL.Services
{
    public class CustomerService : ICustomerService
    {
        //connection string to connect to the database
        string connectionString = ConfigurationManager
            .ConnectionStrings["CustardConnection"]
            .ConnectionString.ToString();

        public DataSet GetDisconnectedData()
        {
            DataSet dataSetCustomer = new DataSet();

            using (MySqlConnection conn = new MySqlConnection(connectionString))//using a MySqlConnection to connect to the database
            {
                //Sql query to be executed in the database
                MySqlCommand command = new MySqlCommand("SELECT * FROM customers;", conn);
                command.CommandType = CommandType.Text;
                MySqlDataAdapter dataAdapterFreelancers = new MySqlDataAdapter(command);

                conn.Open();
                dataAdapterFreelancers.Fill(dataSetCustomer, "customers");

            }

            return dataSetCustomer;
        }


        //custard
        public Customer UpdateCustomer(Customer customer) // For updating the customer details
        {
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                //yet another sql query.
                //the @"field" are for preventing sql injection
                MySqlCommand command = new MySqlCommand(
                    "UPDATE customers SET " +
                    "FirstName = @firstName, " +
                    "LastName = @lastName " +
                    "WHERE Id = @id;", conn);

                //below we are taking the input from the user and executing them as SQL, but done with an "@" to avoid sql injection.
                MySqlParameter first_Name = new MySqlParameter("@firstName", MySqlDbType.VarChar, 200);
                MySqlParameter last_Name = new MySqlParameter("@lastName", MySqlDbType.VarChar, 200);
                MySqlParameter id = new MySqlParameter("@id", MySqlDbType.UInt32, 11);

                first_Name.Value = customer.First_Name;
                last_Name.Value = customer.Last_Name;
                id.Value = customer.Id;

                command.Parameters.Add(first_Name);
                command.Parameters.Add(last_Name);
                command.Parameters.Add(id);

                conn.Open(); //open the connection
                command.Prepare(); // command parameters are prepared.

                int result = command.ExecuteNonQuery(); // execute will return the number of changes, hence the int.

                conn.Close(); //close the connection. You said this was important. :)

                if (result <= 0)
                {
                    return null;
                }

                return customer;
            }
        }


        public bool DeleteCustomer(int customerId)
        {
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                //MySql Query with @ to protect against sql injection
                MySqlCommand command = new MySqlCommand(
                    "DELETE FROM customers " +
                    "WHERE Id = @id;", conn);

                MySqlParameter id =
                    new MySqlParameter("@id", MySqlDbType.UInt32, 11);

                id.Value = customerId;

                command.Parameters.Add(id);
                conn.Open();
                command.Prepare();

                int result = command.ExecuteNonQuery();

                conn.Close();

                if (result <= 0)
                {
                    return false;
                }

                return true;
            }
        }

        public Customer AddCustomer(Customer customer)
        {
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                //MySql Query with @ to protect against sql injection
                MySqlCommand command = new MySqlCommand(
                    "INSERT INTO customers (First_Name, Last_Name, Date_Joined, Time_Joined) " +
                    "VALUES (@First_Name, @Last_Name);", conn);
                //below is input taken from the user but also avoiding sql injection
                MySqlParameter first_Name =
                    new MySqlParameter("@First_Name", MySqlDbType.VarChar, 200);
                MySqlParameter last_Name =
                    new MySqlParameter("@Last_Name", MySqlDbType.VarChar, 200);

                first_Name.Value = customer.First_Name;
                last_Name.Value = customer.Last_Name;
                //opening the connection and preparing the parameters
                command.Parameters.Add(first_Name);
                command.Parameters.Add(last_Name);

                conn.Open();//open connection
                command.Prepare();//prepare the command with the parameters

                int result = command.ExecuteNonQuery(); //method executes a query that does not return results but the number of changes. 
                //If the integer result contains more than 1 we have successfully made changes to the database(inserted a new freelancer)
                conn.Close();// important to close the connection

                if (result <= 0)
                {
                    customer = null; //If the "insert into" statement failed tell the user about it by returning a null object
                }
            }
            return customer; //return the freelancer object back. If there is data we know it worked
        }

        public Customer RetrieveCustomersByLastName(string lastName)
        {
            //Initializing empty object to hold data.
            Customer customer = new Customer();

            MySqlDataReader dataReader;

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                // This is the command to run an SQL query
                MySqlCommand command = new MySqlCommand(
                    "SELECT Id, First_Name, Last_Name " +
                    "FROM customers " +
                    "WHERE Last_Name = @Last_Name;", conn);

                MySqlParameter lastNameParameter =
                    new MySqlParameter("@Last_Name", MySqlDbType.VarChar, 200)
                    {
                        Value = lastName
                    };
                conn.Open();

                command.Parameters.Add(lastNameParameter);
                command.Prepare();

                dataReader = command.ExecuteReader();

                // Return the first row.
                if (dataReader.HasRows)
                {
                    dataReader.Read();

                    customer.First_Name = dataReader.GetString("First_Name");
                    customer.Last_Name = dataReader.GetString("Last_Name");
                    customer.Id = dataReader.GetInt32("Id");
                }
                conn.Close();
            }

            return customer;
        }

        public List<Customer> RetrieveCustomers()
        {
            List<Customer> customers = new List<Customer>();

            MySqlDataReader datareader;
            
            using (MySqlConnection conn = new MySqlConnection(connectionString))//using a MySqlConnection to connect to the database
            {

                //Sql query to be executed in the database
                MySqlCommand command = new MySqlCommand(
                   "SELECT * FROM customers;", conn);
                conn.Open();

                datareader = command.ExecuteReader();

                if (datareader.HasRows)
                {
                    while (datareader.Read())
                    {
                        customers.Add(new Customer(
                            datareader.GetInt32("Id"),
                            datareader.GetString("first_Name"),
                            datareader.GetString("last_Name"),
                            datareader.GetDateTime("date_Joined"),
                            datareader.GetTimeSpan("time_Joined")
                            ));
                    }
                }
                conn.Close();
                return customers;
            }
        }
    }
}
