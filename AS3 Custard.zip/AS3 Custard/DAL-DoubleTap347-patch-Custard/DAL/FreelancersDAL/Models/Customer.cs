﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerDAL.Models
{
    public class Customer
    {
        public Customer() { }
        public Customer(int id, string first_Name, string last_Name)
        {
            Id = id;
            First_Name = first_Name;
            Last_Name = last_Name;
        }

        public Customer(int id, string first_Name, string last_Name, DateTime date_Joined, TimeSpan time_Joined)
        {
            //I like to have underscores for consistency
            Id = id;
            First_Name = first_Name;
            Last_Name = last_Name;
            Date_Joined = date_Joined;
            Time_Joined = time_Joined;
        }

        public int Id { get; set; }
        public string First_Name { get; set; }
        public string Last_Name { get; set; }
        public DateTime Date_Joined { get; set; }
        public TimeSpan Time_Joined { get; set; }
    }
}